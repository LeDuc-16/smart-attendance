package com.leduc.spring.token;

public enum TokenType {
  BEARER
}
