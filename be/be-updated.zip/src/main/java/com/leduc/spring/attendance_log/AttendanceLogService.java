package com.leduc.spring.attendance_log;

import org.springframework.stereotype.Service;

@Service
public class AttendanceLogService{
}
