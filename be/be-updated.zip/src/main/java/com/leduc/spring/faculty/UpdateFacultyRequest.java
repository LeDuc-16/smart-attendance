package com.leduc.spring.faculty;

import lombok.Data;

@Data
public class UpdateFacultyRequest {
    private String facultyName;
}
