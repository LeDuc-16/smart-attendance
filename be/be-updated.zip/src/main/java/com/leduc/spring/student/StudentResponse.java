package com.leduc.spring.student;

import lombok.Data;

@Data
public class StudentResponse {
}
