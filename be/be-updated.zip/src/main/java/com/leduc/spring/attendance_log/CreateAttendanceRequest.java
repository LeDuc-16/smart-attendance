package com.leduc.spring.attendance_log;

import lombok.Data;

@Data
public class CreateAttendanceRequest {
}
