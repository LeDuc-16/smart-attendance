package com.leduc.spring.attendance_log;

public class AttendanceLogController {
    
}
