package com.leduc.spring.attendance_log;

public enum AttendanceStatus {
    PRESENT,     // Đúng giờ
    LATE,        // Muộn
    EXCUSED,     // Có phép
    ABSENT       // Vắng
}
